---
name: NeerNiti Precision Intelligence
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3f4850'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#707881'
  outline-variant: '#bfc7d2'
  surface-tint: '#006398'
  primary: '#006194'
  on-primary: '#ffffff'
  primary-container: '#007bb9'
  on-primary-container: '#fdfcff'
  inverse-primary: '#93ccff'
  secondary: '#006591'
  on-secondary: '#ffffff'
  secondary-container: '#39b8fd'
  on-secondary-container: '#004666'
  tertiary: '#006948'
  on-tertiary: '#ffffff'
  tertiary-container: '#00855d'
  on-tertiary-container: '#f5fff7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cce5ff'
  primary-fixed-dim: '#93ccff'
  on-primary-fixed: '#001d31'
  on-primary-fixed-variant: '#004b73'
  secondary-fixed: '#c9e6ff'
  secondary-fixed-dim: '#89ceff'
  on-secondary-fixed: '#001e2f'
  on-secondary-fixed-variant: '#004c6e'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: 4rem
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.03em
  metric-val:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.875rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes a high-precision, luminous visual standard tailored for national-scale geospatial intelligence, hydrologic analytics, and governance telemetry. The interface merges the structural authority of institutional state instruments with the fluid clarity of contemporary high-end computational software.

The aesthetic fuses **Modern Corporate Realism** with **Analytical Editorial Minimalism**:
- **Pristine Luminosity:** Titanium white canvases, pearl underlays, and optical glass overlays that provide an uncluttered field for dense cartographic, temporal, and aquifer depth metrics.
- **Architectonic Precision:** Structural hair-thin dividers, disciplined data grids, and mathematically proportioned metric groupings inspired by high-end instrumentation consoles and executive editorial publications.
- **Scientific Authority:** Restrained reliance on color; chromas function strictly as semantically weighted indicators (satellite depth sensors, critical recharge anomalies, yield gradients) rather than decorative wallpaper.
- **Executive Composure:** Calm, spacious density orchestration that balances high-volume sensor telemetry with distilled strategic intelligence for policy executives, geoscientists, and field administrators.

## Colors

The palette operates under an absolute light-mode discipline where surfaces evoke clinical clarity, optical depth, and razor-sharp legibility.

### Surface Architecture
- **Base Canvas (`#f8fafc`):** Clean pearl-slate base that anchors viewport canvases and full-screen telemetry layouts.
- **Elevated Canvas (`#ffffff`):** Pure titanium white for analytical cards, sensor viewports, and interactive data sheets.
- **Sub-surface Fill (`#f1f5f9`):** Recessed wells, tabular striping, control troughs, and inactive state fills.

### Ink & Typography Hierarchy
- **Primary Ink (`#0f172a`):** Obsidian deep slate for key metrics, major headlines, and high-impact values.
- **Secondary Ink (`#334155`):** Subdued slate for structural section titles, subheadings, and axis labels.
- **Muted Ink (`#64748b`):** Neutral slate for metadata stamps, unit descriptors, and coordinate indices.

### Precision Accents & Sensor Chromatics
- **Primary Sensor Azure (`#0284c7`):** Primary interaction cues, hydraulic vector paths, and selected telemetry layers.
- **Secondary Satellite Cyan (`#0ea5e9`):** Sub-surface aquifer scans, active scan lines, and hovered telemetry items.
- **Deep Hydro Blue (`#0369a1`):** Active structural tabs, high-confidence confidence intervals, and focused outlines.
- **Recharge Emerald (`#059669`):** Positive aquifer recharge, balanced hydrological balance, and verified field sensor pings.
- **Depletion Amber / Critical Red:** Muted alerts (`#d97706` / `#dc2626`) calibrated to deliver immediate urgency against white backdrops without causing visual fatigue.

## Typography

The typographic hierarchy couples **Plus Jakarta Sans** for modern architectural headings and high-impact numeric values with **Inter** for dense tabular readouts, system controls, and cartographic labeling.

- **Editorial Stature:** Headlines leverage tightened tracking (`-0.01em` to `-0.03em`) and restrained vertical line heights to evoke high-end analytical briefs.
- **Tabular Figures & Metrics:** All numeric values, coordinates, depth readings, and telemetry gauges enforce tabular figure settings (`font-variant-numeric: tabular-nums`) to prevent layout shifting during real-time telemetry updates.
- **Micro-Labels & Technical Annotations:** Labels use medium-to-semibold weights with slight positive letter spacing to retain structural clarity across sub-pixel raster renderings and high-DPI displays.

## Layout & Spacing

The layout model enforces a strict 12-column adaptive fluid grid designed to display concurrent geospatial layers, control trays, and contextual telemetry drawers.

### Structural Breakpoints
- **Desktop (1440px+):** 12 columns, 32px margins, 24px gutters. Tri-pane layouts: Left GIS parameter inspector (3 cols), Central dynamic viewport (6 cols), Right hydrological anomaly feed (3 cols).
- **Tablet (768px - 1439px):** 8 columns, 24px margins, 16px gutters. Collapsible sidebars; map and key data visualizers retain primary viewport dominance.
- **Mobile (<768px):** 4 columns, 16px margins, 12px gutters. Telemetry panels collapse into bottom sheets with persistent micro-metric status ribbons.

### Spacing Cadence
- Element groupings inside cards and analytical panels follow strict 4px base units (`space-xs` through `space-xl`).
- Structural cards use internal inset padding of `space-lg` (24px) for desktop data cards and `space-md` (16px) for nested lists and controls.

## Elevation & Depth

Visual hierarchy does not rely on heavy drop shadows. Depth is achieved via **tonal stratification, frosted glass backdrops, and hairline boundaries**:

- **Ground Level (Elevation 0):** Flat `#f8fafc` background canvas.
- **Base Modules (Elevation 1):** Solid `#ffffff` surface enclosed by a calibrated hairline border (`border: 1px solid rgba(226, 232, 240, 0.8)`). Grounded by a delicate ambient shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.03), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Floating Sensor HUD & Overlays (Elevation 2):** Semi-translucent frosted glass (`rgba(255, 255, 255, 0.88)` with `backdrop-filter: blur(12px)`), bound by an illuminated inner specular ring (`box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.9)`) and a subtle perimeter shadow: `0 4px 16px -2px rgba(15, 23, 42, 0.06)`.
- **Command Sheets & Critical Modals (Elevation 3):** High-density modal surfaces floating over a calibrated dampening veil (`rgba(15, 23, 42, 0.2)` with `backdrop-filter: blur(4px)`). Shadow: `0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.

## Shapes

The design system implements a refined **Level 2 (Rounded)** curvature profile. Radii balance Apple-level software fluidity with the disciplined square profiles of scientific instruments.

- **Base Radius (`0.5rem` / 8px):** Standard inputs, operational buttons, dropdown trays, and secondary chips.
- **Card & Container Radius (`1rem` / 16px - `rounded-lg`):** Telemetry cards, floating map panels, and analytical insight blocks.
- **Major Surface Radius (`1.5rem` / 24px - `rounded-xl`):** Primary application dialogs, persistent floating command docks, and bottom sheets.
- **Pill Radius (`9999px`):** Status indicators, confidence score tags, and map coordinate chips.

## Components

### Buttons & Operational Actions
- **Primary Command:** Solid `#0284c7` fill, white text, 8px radius, subtle top specular highlight (`inset 0 1px 0 rgba(255, 255, 255, 0.2)`). On hover, subtle luminance shift to `#0ea5e9` with `box-shadow: 0 4px 12px rgba(2, 132, 199, 0.24)`.
- **Secondary Surface:** Titanium white `#ffffff` fill, `#0f172a` text, perimeter stroke `1px solid #e2e8f0`. Hover transitions to `#f8fafc` with border `#cbd5e1`.
- **Ghost/Tertiary:** Transparent fill, `#334155` text, shifting to `rgba(2, 132, 199, 0.08)` and `#0284c7` on interactive states.

### Status Indicators & Badges
- **Hydrological Chips:** Elliptical indicators (`rounded-full`) composed of a tinted frosted fill (e.g., `#059669` at 10% opacity), crisp semantic text (`#059669`), hairline border (`rgba(5, 150, 105, 0.2)`), and a 6px luminous pulsing status pip.

### Analytical Data Cards
- Pure `#ffffff` surfaces enveloped in `1px solid rgba(226, 232, 240, 0.8)`.
- Header zone split by a hairline horizontal divider (`1px solid #f1f5f9`), featuring a crisp section tag (`label-sm`), main metric in high-contrast `Plus Jakarta Sans`, and a secondary sparkline or differential delta.

### Precision Input Fields & Dropdowns
- Height of 40px, neutral background `#ffffff`, border `1px solid #cbd5e1`, text `#0f172a`.
- Focus state: Border transitions to `#0284c7`, supported by an ambient outer glow ring `0 0 0 3px rgba(2, 132, 199, 0.15)`.
- Numeric input fields integrate trailing unit labels (`m bgl`, `ha-m`, `km²`) styled in muted `Inter` 12px.

### Geospatial HUD Panels & Map Overlays
- Docked panels utilize frosted acrylic glass (`rgba(255, 255, 255, 0.9)` with 16px blur).
- Layer toggles employ miniature segmented controls with a 2px pearl container track and titanium white sliding segment indicator.